package com.example.police_mitra;

public class UserHelperClass4 {

    String city;

    UserHelperClass4(){
    }

    UserHelperClass4(String city){
        this.city=city;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
